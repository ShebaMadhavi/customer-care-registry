const express = require("express");
const router = express.Router();
const Ticket = require("../models/Ticket");

// ======================
// CREATE
// ======================
router.post("/", async (req, res) => {
  try {
    const ticket = await Ticket.create({
      title: req.body.title,
      description: req.body.description,
      priority: req.body.priority || "Medium",
      status: "Open",
    });

    res.status(201).json(ticket);
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

// ======================
// READ
// ======================
router.get("/", async (req, res) => {
  try {
    const tickets = await Ticket.find().sort({
      createdAt: -1,
    });

    res.json(tickets);
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

// ======================
// DELETE
// ======================
router.delete("/:id", async (req, res) => {
  try {
    const ticket = await Ticket.findByIdAndDelete(req.params.id);

    if (!ticket) {
      return res.status(404).json({
        error: "Ticket not found",
      });
    }

    res.json({
      message: "Ticket deleted successfully",
    });
  } catch (err) {
    res.status(500).json({
      error: err.message,
    });
  }
});

module.exports = router;