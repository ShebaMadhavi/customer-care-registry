import { useEffect, useState } from 'react';
import axios from 'axios';

const TicketList = () => {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);

  // Auto-Refresh
  useEffect(() => {
    const fetchTickets = async () => {
      try {
        const res = await axios.get('http://127.0.0.1:5000/api/tickets');
        setTickets(Array.isArray(res.data) ? res.data : []);
        setLoading(false);
      } catch (err) {
        setLoading(false);
      }
    };
    fetchTickets();
    const interval = setInterval(fetchTickets, 3000); 
    return () => clearInterval(interval);
  }, []);

  const getPriorityColor = (p) => {
    const priority = p ? p.toLowerCase() : 'medium';
    if (priority === 'high') return '#ff3333';
    if (priority === 'medium') return '#ffff00';
    return '#00ff88';
  };

  // --- COMPACT LIST STYLE ---
  return (
    <div style={{ width: '100%' }}>
      {/* Header */}
      <h3 style={{ 
        color: '#00ff88', fontFamily: 'monospace', fontSize: '12px', 
        borderBottom: '1px solid #333', paddingBottom: '5px', margin: '0 0 10px 0', textAlign: 'center' 
      }}>
        {'>'} RECENT_LOGS [{tickets.length}]
      </h3>

      {/* Scrollable Mini-List */}
      <div style={{ 
        maxHeight: '200px',     /* Very small height (about 3-4 items) */
        overflowY: 'auto',      
        paddingRight: '5px'     
      }}>
        
        {tickets.map((ticket) => (
          <div key={ticket._id || Math.random()} style={{
            background: 'rgba(0, 0, 0, 0.6)',
            borderLeft: `2px solid ${getPriorityColor(ticket.priority)}`, /* Thinner border */
            marginBottom: '8px',
            padding: '8px',        /* Smaller padding */
            borderRadius: '4px',
            fontFamily: 'monospace'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ color: '#fff', fontSize: '11px', fontWeight: 'bold' }}>
                {ticket.title || 'Untitled'}
              </span>
              <span style={{ color: getPriorityColor(ticket.priority), fontSize: '9px', border: '1px solid #333', padding: '1px 4px', borderRadius: '3px' }}>
                {ticket.priority ? ticket.priority.toUpperCase() : 'MED'}
              </span>
            </div>
            
            <div style={{ fontSize: '10px', color: '#888', marginTop: '2px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {ticket.description}
            </div>
          </div>
        ))}
        
        {tickets.length === 0 && !loading && (
          <div style={{ color: '#444', fontStyle: 'italic', fontSize: '10px', textAlign: 'center' }}>// Empty Registry</div>
        )}
      </div>
    </div>
  );
};

export default TicketList;
