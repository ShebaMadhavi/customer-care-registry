import { useState, useEffect } from 'react';
import axios from 'axios';

const CreateTicket = () => {
  const [formData, setFormData] = useState({ title: '', description: '', priority: 'Medium' });
  const [status, setStatus] = useState(null); 
  const [tickets, setTickets] = useState([]);
  const [loadingInitial, setLoadingInitial] = useState(true);

  // FIXED: RESTORED COMPLETED ENDPOINT ROUTE STRING
  const API_BASE_URL = "http://127.0.0.1:5000/api/tickets";

  /* 
    FEATURE 1: LIFE-CYCLE TIMELINE SYNCHRONIZATION
    Fetches pre-existing database ticket records on component mount.
  */
  useEffect(() => {
    const fetchExistingTickets = async () => {
      try {
        const res = await axios.get(API_BASE_URL);
        if (Array.isArray(res.data)) {
          setTickets(res.data);
        }
      } catch (err) {
        console.error("Failed to sync database timeline:", err);
      } finally {
        setLoadingInitial(false);
      }
    };
    fetchExistingTickets();
  }, []);

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  /* 
    FEATURE 2: REAL-TIME RESPONSE RENDERING
    Transmits code entry to the server and handles response mutations.
  */
  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus('loading');
    try {
      const res = await axios.post(API_BASE_URL, formData);
      const newTicket = res.data;
      
      setStatus(`> Log #${newTicket._id ? newTicket._id.slice(-6).toUpperCase() : 'SAVED'} Verified`);
      
      // Prepends the new database entry cleanly to the top of the collection list
      setTickets((prevTickets) => [newTicket, ...prevTickets]);
      setFormData({ title: '', description: '', priority: 'Medium' });
    } catch (err) {
      setStatus('! Error: ' + (err.response?.data?.error || err.message));
    }
  };

  /* 
    FEATURE 3: HARDWARE INSTANT DELETE REGULATION
    Dispatches a DELETE signal to the backend while purifying the current client viewport state array.
  */
  const handleDeleteTicket = async (id) => {
    if (!id) return;
    try {
      await axios.delete(`${API_BASE_URL}/${id}`);
      setTickets((prevTickets) => prevTickets.filter(ticket => ticket._id !== id));
    } catch (err) {
      alert(`Terminal command rejected: ${err.message}`);
    }
  };

  return (
    /* 
      SYMMETRICAL MASTER VIEWPORT WRAPPER
      Maintains exact mathematical layout center using 100vw/100vh constraints.
      Eliminates side-shifting conflicts while enabling uniform continuous page scrolling.
    */
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      width: '100vw',
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center', 
      overflowY: 'auto',       
      padding: '40px 16px',    
      boxSizing: 'border-box',
      zIndex: 999              
    }}>
      
      {/* SECTION 1: EXECUTION COMMAND ENTRY FORM */}
      <div className="glass-console" style={{ 
        padding: '20px', 
        width: '100%',
        maxWidth: '420px', 
        boxSizing: 'border-box',
        marginBottom: '24px',
        flexShrink: 0          
      }}>
        <div style={{ marginBottom: '15px', borderBottom: '1px solid #333', paddingBottom: '8px' }}>
          <h2 style={{ margin: 0, color: '#fff', fontSize: '14px', letterSpacing: '1px', fontFamily: 'monospace' }}>
            <span style={{ color: '#00ff88' }}>$</span> NEW_ENTRY_CORE
          </h2>
        </div>

        {status && (
          <div style={{ 
            padding: '10px', marginBottom: '15px', fontSize: '11px', fontFamily: 'monospace',
            background: '#0a0a0a', border: '1px solid #222', borderLeft: status.includes('Verified') ? '3px solid #00ff88' : '3px solid #f00',
            color: status.includes('Verified') ? '#00ff88' : '#ff3333', borderRadius: '4px'
          }}>
            {status === 'loading' ? '> Transmitting Data stream...' : status}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: '12px' }}>
            <label style={{ color: '#666', fontSize: '10px', display: 'block', marginBottom: '4px', fontFamily: 'monospace' }}>SUBJECT_LINE</label>
            <input 
              type="text" name="title" value={formData.title} onChange={handleChange} required 
              style={{ 
                width: '100%', padding: '10px', background: '#050505', border: '1px solid #222', 
                color: '#00ff88', fontFamily: 'monospace', borderRadius: '4px', outline: 'none',
                boxSizing: 'border-box'
              }} 
            />
          </div>

          <div style={{ marginBottom: '12px' }}>
            <label style={{ color: '#666', fontSize: '10px', display: 'block', marginBottom: '4px', fontFamily: 'monospace' }}>RAW_DETAILS</label>
            <textarea 
              name="description" value={formData.description} onChange={handleChange} required 
              style={{ 
                width: '100%', height: '75px', padding: '10px', background: '#050505', border: '1px solid #222', 
                color: '#00ff88', fontFamily: 'monospace', borderRadius: '4px', outline: 'none', resize: 'none',
                boxSizing: 'border-box', lineHeight: '1.4'
              }} 
            />
          </div>

          <div style={{ marginBottom: '18px' }}>
            <label style={{ color: '#666', fontSize: '10px', display: 'block', marginBottom: '4px', fontFamily: 'monospace' }}>PRIORITY_WEIGHT</label>
            <select 
              name="priority" value={formData.priority} onChange={handleChange}
              style={{ 
                width: '100%', padding: '10px', background: '#050505', border: '1px solid #222', 
                color: '#00ff88', fontFamily: 'monospace', borderRadius: '4px', cursor: 'pointer',
                boxSizing: 'border-box'
              }}
            >
              <option value="Low">Low_Latency [Tier_3]</option>
              <option value="Medium">Standard_Ops [Tier_2]</option>
              <option value="High">Critical_Failure [Tier_1]</option>
            </select>
          </div>

          <button type="submit" style={{ 
            width: '100%', padding: '12px', background: '#00ff88', color: '#000', border: 'none', 
            borderRadius: '4px', fontWeight: 'bold', fontSize: '11px', cursor: 'pointer', letterSpacing: '1px',
            fontFamily: 'monospace'
          }}>
            EXECUTE_LOG()
          </button>
        </form>
      </div>

      {/* SECTION 2: LIVE RESPONSIVE DYNAMIC TRACKING STREAM */}
      <div style={{ 
        display: 'flex', 
        flexDirection: 'column', 
        gap: '12px', 
        width: '100%', 
        maxWidth: '420px',
        marginBottom: '24px',
        flexShrink: 0
      }}>
        {/* Counter Heading */}
        <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid #222', paddingBottom: '6px', marginBottom: '4px' }}>
          <span style={{ color: '#666', fontSize: '11px', fontFamily: 'monospace', letterSpacing: '1px' }}>
            &gt; RECENT_LOGS [{tickets.length}]
          </span>
          {loadingInitial && <span style={{ color: '#00ff88', fontSize: '10px', fontFamily: 'monospace' }}>SYNCING...</span>}
        </div>

        {/* Dynamic Mapping Core */}
        {tickets.length === 0 ? (
          <div style={{
            padding: '16px', border: '1px dashed #222', borderRadius: '4px',
            color: '#444', fontFamily: 'monospace', fontSize: '11px', textAlign: 'center'
          }}>
            [No active operational logs currently detected in local array]
          </div>
        ) : (
          tickets.map((ticket, index) => (
            /* FIXED: Cleaned up trailing brackets from map boundaries */
            <div key={ticket._id || index} className="glass-console" style={{
              padding: '14px',
              border: '1px solid #222',
              background: 'rgba(10, 10, 10, 0.85)',
              borderRadius: '4px',
              fontFamily: 'monospace',
              boxSizing: 'border-box'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                <span style={{ color: '#00ff88', fontSize: '11px', fontWeight: 'bold' }}>
                  #{ticket._id ? ticket._id.slice(-6).toUpperCase() : `LOC_${index}`}
                </span>
                
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <span style={{ 
                    color: ticket.priority === 'High' ? '#ff3333' : ticket.priority === 'Low' ? '#3399ff' : '#00ff88',
                    fontSize: '10px', background: '#000', padding: '2px 6px', borderRadius: '3px', border: '1px solid #111'
                  }}>
                    {ticket.priority.toUpperCase()}
                  </span>
                  
                  <button 
                    onClick={() => handleDeleteTicket(ticket._id)}
                    style={{
                      background: 'none', border: 'none', color: '#555', cursor: 'pointer',
                      fontSize: '14px', fontWeight: 'bold', padding: '0 2px'
                    }}
                    title="Terminate Log Entry"
                  >
                    ×
                  </button>
                </div>
              </div>
              
              <div style={{ color: '#fff', fontSize: '13px', marginBottom: '6px', fontWeight: 'bold' }}>
                {ticket.title}
              </div>
              <div style={{ color: '#8aa193', fontSize: '11px', lineHeight: '1.5', wordBreak: 'break-word' }}>
                {ticket.description}
              </div>
            </div>
          ))
        )}
      </div>

      {/* SECTION 3: SYSTEM METADATA / GROUP DIRECTORY */}
      {/* SECTION 3: SYSTEM METADATA / GROUP DIRECTORY */}
      <div className="glass-console" style={{ 
        padding: '20px', 
        width: '100%',
        maxWidth: '420px', 
        boxSizing: 'border-box',
        border: '1px dashed #333',
        background: 'rgba(5, 5, 5, 0.95)',
        fontFamily: 'monospace',
        flexShrink: 0,
        marginBottom: '20px'
      }}>
        <div style={{ marginBottom: '12px', borderBottom: '1px dashed #333', paddingBottom: '6px' }}>
          <h3 style={{ margin: 0, color: '#fff', fontSize: '12px', letterSpacing: '1px' }}>
            <span style={{ color: '#00ff88' }}>#</span> ABOUT_CORE_MODULE
          </h3>
        </div>

        <p style={{ color: '#777', fontSize: '11px', lineHeight: '1.5', margin: '0 0 15px 0' }}>
          A secure, high-performance console log engine designed for tracking and managing operational network tickets efficiently. Engineered with optimized React reconciliation algorithms.
        </p>

        <div style={{ color: '#555', fontSize: '10px', marginBottom: '8px', letterSpacing: '0.5px' }}>
          PROJECT_CONTRIBUTORS:
        </div>

        <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '6px' }}>
          {[
            'Ananya Pantula',
            'Polamarsetti Govardhini',
            'Kalyan Ram Rambarika',
            'Sivakoti Sandhya',
            'Sheba Madhavi Elipe'
          ].map((name, i) => (
            <li key={i} style={{ fontSize: '11px', display: 'flex', alignItems: 'center', gap: '10px' }}>
              <span style={{ color: '#333', userSelect: 'none' }}>[{i + 1}]</span>
              <span style={{ color: '#e0e0e0' }}>{name}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default CreateTicket;
