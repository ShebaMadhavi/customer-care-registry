import CreateTicket from "./components/CreateTicket";

function App() {
  return <CreateTicket />;
}

export default App;